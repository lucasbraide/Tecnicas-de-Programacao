public interface IDecorator{
    void decorar();
}
